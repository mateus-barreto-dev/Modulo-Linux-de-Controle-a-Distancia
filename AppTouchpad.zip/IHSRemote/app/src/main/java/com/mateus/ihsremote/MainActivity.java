package com.mateus.ihsremote;

//-----------------Coisas do Android------------------
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
//----------------------------------------------------
//---------------------TCP----------------------------
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
//----------------------------------------------------
//--------------------Depuração-----------------------
import android.util.Log;
//----------------------------------------------------
//----------------MovimentoMouse----------------------
import android.view.GestureDetector;
import android.view.MotionEvent;
//----------------------------------------------------
//-----------------FilaComandos-----------------------
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
//----------------------------------------------------



public class MainActivity extends AppCompatActivity {
    private final BlockingQueue<String> fila = new LinkedBlockingQueue<>(); //fila de comandos
    private float posX = 0, posY = 0, dX = 0, dY = 0, lastX = 0, lastY = 0; //Movimento do Mouse

    private float mediaY_scroll = 0, lastY_scroll = 0; //Movimento do Scroll
    private boolean primeiroScroll = true;
    Socket socket; //Cria o socket
    PrintWriter writer; //Cria uma classe para receber os comandos

    private GestureDetector detector; //Detector de Gestos

    private void offerCommand(String command) {

        fila.offer(command);
    }


    public void moverMouse(float dX, float dY){
        if ((Math.abs(dX) > 2 || Math.abs(dY) > 2)){
            offerCommand("MOVE " + Math.round(dX) +" "+ Math.round(dY));
            lastX = posX; lastY = posY;
        }
    }

    public void moverScroll(float dY){
        if ((Math.abs(dY) > 2)){
            offerCommand("WHEEL " + Math.round(dY));
            lastY_scroll = mediaY_scroll;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) { //Cria tudo no aplicativo
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); //ocupar a tela toda
        setContentView(R.layout.activity_main); //Carregar o Arquivo xml
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });







        detector = new GestureDetector(
                this,
                new GestureDetector.SimpleOnGestureListener() {


                    @Override
                    public boolean onDoubleTap(MotionEvent event) {

                        offerCommand("LBC");
                        Log.d("IHS", "Double Tap Left");
                        return true;
                    }

                    @Override
                    public void onLongPress(MotionEvent event){

                        Log.d("IHS", "Segurou a Tela");
                        offerCommand("RBC");

                    }
                }
        );

        findViewById(R.id.main).setOnTouchListener((v, event) -> { //Recebe eventos do meu celular


            if (event.getPointerCount() == 1) {
                posX = event.getX();
                posY = event.getY();
            }
            if (event.getPointerCount() == 2){
                mediaY_scroll = (event.getY(0)+ event.getY(1))/2.0f;
            }

            detector.onTouchEvent(event);

            switch (event.getActionMasked()) {

                case MotionEvent.ACTION_DOWN:

                    lastX = posX;
                    lastY = posY;
                    lastY_scroll = mediaY_scroll;
                    break;


                case MotionEvent.ACTION_MOVE:

                    if (event.getPointerCount() == 1) {
                        dX = posX - lastX;
                        dY = posY - lastY;
                        moverMouse(dX, dY);
                    }
                    if (event.getPointerCount() == 2){
                        moverScroll(mediaY_scroll - lastY_scroll);
                    }
                    break;
            }

            return true;
        });



        new Thread(() -> { //Cria uma thread para ficar executando a parte de conexão

            try {

                Log.d("IHS", "Entrou no try");

                socket = new Socket("10.0.0.181", 5558); //bind do socket com meu hostname e porta

                Log.d("IHS", "Socket criado");

                writer = new PrintWriter(socket.getOutputStream(), true); //true faz com que assim que escrever envie para a saída

                Log.d("IHS", "Writer criado");

                while (!Thread.currentThread().isInterrupted()) {
                    String sendCMD = fila.take();
                    writer.println(sendCMD);
                }
            } catch (IOException e) {
                Log.e("IHS", "Erro de IO", e);
            } catch (InterruptedException e) {
                Log.e("IHS", "Erro de Runtime", e);
                throw new RuntimeException(e);
            }

        }).start();



















   }
}